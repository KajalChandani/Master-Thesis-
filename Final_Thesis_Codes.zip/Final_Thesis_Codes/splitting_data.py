#!/usr/bin/env python
# coding: utf-8

# In[1]:


import os, shutil
from distutils.dir_util import copy_tree


# In[2]:


# The path to the directory where the original
# dataset was uncompressed
original_dir_3pointerfailure = 'C:/frames1/3-pointer failure'
original_dir_3pointersuccess = 'C:/frames1/3-pointer success'
original_dir_freethrowfailure = 'C:/frames1/free-throw failure'
original_dir_freethrowsuccess = 'C:/frames1/free-throw success'
original_dir_layupfailure = 'C:/frames1/layup failure'
original_dir_layupsuccess = 'C:/frames1/layup success'
original_dir_other2pointerfailure = 'C:/frames1/other 2-pointer failure'
original_dir_other2pointersuccess = 'C:/frames1/other 2-pointer success'
original_dir_slamdunkfailure = 'C:/frames1/slam dunk failure'
original_dir_slamdunksuccess = 'C:/frames1/slam dunk success'
original_dir_stealsuccess = 'C:/frames1/steal success'


# The directory where we will
# store our smaller dataset
base_dir = 'E:/data partition'
if not os.path.exists(base_dir):
        os.mkdir(base_dir)

# Directories for our training,
# validation and test splits 
train_dir = os.path.join(base_dir, 'train')
if not os.path.exists(train_dir):
    os.mkdir(train_dir)

val_dir = os.path.join(base_dir, 'validation')
if not os.path.exists(val_dir):
    os.mkdir(val_dir)

test_dir = os.path.join(base_dir, 'test')
if not os.path.exists(test_dir):
    os.mkdir(test_dir)


# In[3]:


#Directory with our train shots
# 1 
train_3pointerfailure_dir = os.path.join(train_dir, '3pointerfailure')
if not os.path.exists(train_3pointerfailure_dir):
    os.mkdir(train_3pointerfailure_dir)

# 2 
train_3pointersuccess_dir = os.path.join(train_dir, '3pointersuccess')
if not os.path.exists(train_3pointersuccess_dir):
    os.mkdir(train_3pointersuccess_dir)
    
# 3 
train_freethrowfailure_dir = os.path.join(train_dir, 'freethrowfailure')
if not os.path.exists(train_freethrowfailure_dir):
    os.mkdir(train_freethrowfailure_dir)

# 4 
train_freethrowsuccess_dir = os.path.join(train_dir, 'freethrowsuccess')
if not os.path.exists(train_freethrowsuccess_dir):
    os.mkdir(train_freethrowsuccess_dir)
    
# 5 
train_layupfailure_dir = os.path.join(train_dir, 'layupfailure')
if not os.path.exists(train_layupfailure_dir):
    os.mkdir(train_layupfailure_dir)

# 6 
train_layupsuccess_dir = os.path.join(train_dir, 'layupsuccess')
if not os.path.exists(train_layupsuccess_dir):
    os.mkdir(train_layupsuccess_dir)
    
# 7 
train_other2pointerfailure_dir = os.path.join(train_dir, 'other2pointerfailure')
if not os.path.exists(train_other2pointerfailure_dir):
    os.mkdir(train_other2pointerfailure_dir)

# 8 
train_other2pointersuccess_dir = os.path.join(train_dir, 'other2pointersuccess')
if not os.path.exists(train_other2pointersuccess_dir):
    os.mkdir(train_other2pointersuccess_dir)
    
# 9 
train_slamdunkfailure_dir = os.path.join(train_dir, 'slamdunkfailure')
if not os.path.exists(train_slamdunkfailure_dir):
    os.mkdir(train_slamdunkfailure_dir)
    
# 10 
train_slamdunksuccess_dir = os.path.join(train_dir, 'slamdunksuccess')
if not os.path.exists(train_slamdunksuccess_dir):
    os.mkdir(train_slamdunksuccess_dir)

# 11 
'''train_stealsuccess_dir = os.path.join(train_dir, 'stealsuccess')
if not os.path.exists(train_stealsuccess_dir):
    os.mkdir(train_stealsuccess_dir)'''



# In[5]:


#Directory with our val shots
# 1 
val_3pointerfailure_dir = os.path.join(val_dir, '3pointerfailure')
if not os.path.exists(val_3pointerfailure_dir):
    os.mkdir(val_3pointerfailure_dir)

# 2 
val_3pointersuccess_dir = os.path.join(val_dir, '3pointersuccess')
if not os.path.exists(val_3pointersuccess_dir):
    os.mkdir(val_3pointersuccess_dir)
    
# 3 
val_freethrowfailure_dir = os.path.join(val_dir, 'freethrowfailure')
if not os.path.exists(val_freethrowfailure_dir):
    os.mkdir(val_freethrowfailure_dir)

# 4 
val_freethrowsuccess_dir = os.path.join(val_dir, 'freethrowsuccess')
if not os.path.exists(val_freethrowsuccess_dir):
    os.mkdir(val_freethrowsuccess_dir)
    
# 5 
val_layupfailure_dir = os.path.join(val_dir, 'layupfailure')
if not os.path.exists(val_layupfailure_dir):
    os.mkdir(val_layupfailure_dir)

# 6 
val_layupsuccess_dir = os.path.join(val_dir, 'layupsuccess')
if not os.path.exists(val_layupsuccess_dir):
    os.mkdir(val_layupsuccess_dir)
    
# 7 
val_other2pointerfailure_dir = os.path.join(val_dir, 'other2pointerfailure')
if not os.path.exists(val_other2pointerfailure_dir):
    os.mkdir(val_other2pointerfailure_dir)

# 8 
val_other2pointersuccess_dir = os.path.join(val_dir, 'other2pointersuccess')
if not os.path.exists(val_other2pointersuccess_dir):
    os.mkdir(val_other2pointersuccess_dir)
    
# 9 
val_slamdunkfailure_dir = os.path.join(val_dir, 'slamdunkfailure')
if not os.path.exists(val_slamdunkfailure_dir):
    os.mkdir(val_slamdunkfailure_dir)
    
# 10 
val_slamdunksuccess_dir = os.path.join(val_dir, 'slamdunksuccess')
if not os.path.exists(val_slamdunksuccess_dir):
    os.mkdir(val_slamdunksuccess_dir)

# 11 
'''val_stealsuccess_dir = os.path.join(val_dir, 'stealsuccess')
if not os.path.exists(val_stealsuccess_dir):
    os.mkdir(val_stealsuccess_dir)'''



# In[6]:


# Directory with our test shots
# 1 
test_3pointerfailure_dir = os.path.join(test_dir, '3pointerfailure')
if not os.path.exists(test_3pointerfailure_dir):
    os.mkdir(test_3pointerfailure_dir)

# 2 
test_3pointersuccess_dir = os.path.join(test_dir, '3pointersuccess')
if not os.path.exists(test_3pointersuccess_dir):
    os.mkdir(test_3pointersuccess_dir)
    
# 
test_freethrowfailure_dir = os.path.join(test_dir, 'freethrowfailure')
if not os.path.exists(test_freethrowfailure_dir):
    os.mkdir(test_freethrowfailure_dir)

# 4 
test_freethrowsuccess_dir = os.path.join(test_dir, 'freethrowsuccess')
if not os.path.exists(test_freethrowsuccess_dir):
    os.mkdir(test_freethrowsuccess_dir)
    
# 5 
test_layupfailure_dir = os.path.join(test_dir, 'layupfailure')
if not os.path.exists(test_layupfailure_dir):
    os.mkdir(test_layupfailure_dir)

# 6 
test_layupsuccess_dir = os.path.join(test_dir, 'layupsuccess')
if not os.path.exists(test_layupsuccess_dir):
    os.mkdir(test_layupsuccess_dir)
    
# 7 
test_other2pointerfailure_dir = os.path.join(test_dir, 'other2pointerfailure')
if not os.path.exists(test_other2pointerfailure_dir):
    os.mkdir(test_other2pointerfailure_dir)

# 8 
test_other2pointersuccess_dir = os.path.join(test_dir, 'other2pointersuccess')
if not os.path.exists(test_other2pointersuccess_dir):
    os.mkdir(test_other2pointersuccess_dir)
    
# 9 
test_slamdunkfailure_dir = os.path.join(test_dir, 'slamdunkfailure')
if not os.path.exists(test_slamdunkfailure_dir):
    os.mkdir(test_slamdunkfailure_dir)
    
# 10 
test_slamdunksuccess_dir = os.path.join(test_dir, 'slamdunksuccess')
if not os.path.exists(test_slamdunksuccess_dir):
    os.mkdir(test_slamdunksuccess_dir)

# 11 
'''test_stealsuccess_dir = os.path.join(test_dir, 'stealsuccess')
if not os.path.exists(test_stealsuccess_dir):
    os.mkdir(test_stealsuccess_dir)'''


# In[9]:


events = os.listdir('C:/frames1')
#print(events)

for event in events:
    if event == '3-pointer failure':
        train_data1 = int(round(((len(os.listdir('C:/frames1/'+ event)))*.4),0))
        test_data1 = int(round(((len(os.listdir('C:/frames1/'+ event)))*.1),0)) 
        val_data1 = int(round(((len(os.listdir('C:/frames1/'+ event)))*.1),0))
        
    if event == '3-pointer success':
        train_data2 = int(round(((len(os.listdir('C:/frames1/'+ event)))*.4),0))
        test_data2 = int(round(((len(os.listdir('C:/frames1/'+ event)))*.1),0))
        val_data2 = int(round(((len(os.listdir('C:/frames1/'+ event)))*.1),0))
        
    if event == 'free-throw failure':
        train_data3 = int(round(((len(os.listdir('C:/frames1/'+ event)))*.4),0))
        test_data3 = int(round(((len(os.listdir('C:/frames1/'+ event)))*.1),0))
        val_data3 = int(round(((len(os.listdir('C:/frames1/'+ event)))*.1),0))
        
    if event == 'free-throw success':
        train_data4 = int(round(((len(os.listdir('C:/frames1/'+ event)))*.4),0))
        test_data4 = int(round(((len(os.listdir('C:/frames1/'+ event)))*.1),0))
        val_data4 = int(round(((len(os.listdir('C:/frames1/'+ event)))*.1),0))
        
    if event == 'layup failure':
        train_data5 = int(round(((len(os.listdir('C:/frames1/'+ event)))*.4),0))
        test_data5 = int(round(((len(os.listdir('C:/frames1/'+ event)))*.1),0))
        val_data5 = int(round(((len(os.listdir('C:/frames1/'+ event)))*.1),0))
        
    if event == 'layup success':
        train_data6 = int(round(((len(os.listdir('C:/frames1/'+ event)))*.4),0))
        test_data6 = int(round(((len(os.listdir('C:/frames1/'+ event)))*.1),0))
        val_data6 = int(round(((len(os.listdir('C:/frames1/'+ event)))*.1),0))
        
        
    if event == 'other 2-pointer failure':
        train_data7 = int(round(((len(os.listdir('C:/frames1/'+ event)))*.4),0))
        test_data7 = int(round(((len(os.listdir('C:/frames1/'+ event)))*.1),0))
        val_data7 = int(round(((len(os.listdir('C:/frames1/'+ event)))*.1),0))
        
    if event == 'other 2-pointer success':
        train_data8 = int(round(((len(os.listdir('C:/frames1/'+ event)))*.4),0))
        test_data8 = int(round(((len(os.listdir('C:/frames1/'+ event)))*.1),0))
        val_data8 = int(round(((len(os.listdir('C:/frames1/'+ event)))*.1),0))
        
        
    if event == 'slam dunk failure':
        train_data9 = int(round(((len(os.listdir('C:/frames1/'+ event)))*.4),0))
        test_data9 = int(round(((len(os.listdir('C:/frames1/'+ event)))*.1),0))
        val_data9 = int(round(((len(os.listdir('C:/frames1/'+ event)))*.1),0))
        
    if event == 'slam dunk success':
        train_data10= int(round(((len(os.listdir('C:/frames1/'+ event)))*.4),0))
        test_data10= int(round(((len(os.listdir('C:/frames1/'+ event)))*.1),0))
        val_data10 = int(round(((len(os.listdir('C:/frames1/'+ event)))*.1),0))
        
    '''if event == 'steal success':
        train_data11 = int(round(((len(os.listdir('C:/frames1/'+ event)))*.8),0))
        test_data11 = int(round(((len(os.listdir('C:/frames1/'+ event)))*.2),0))'''
        
       


# In[10]:


# Copy first few shots to train directories

#1 
fnames = ['{}'.format(i) for i in range(1,train_data1+1)]
for fname in fnames:
    src = os.path.join(original_dir_3pointerfailure, fname)
    dest = os.path.join(train_3pointerfailure_dir, fname)
    
    if os.path.isdir(src):
        shutil.copytree(src, dest)
    else:
        shutil.copy2(src, dest)
        
#2 
fnames = ['{}'.format(i) for i in range(1,train_data2+1)]
for fname in fnames:
    src = os.path.join(original_dir_3pointersuccess, fname)
    dest = os.path.join(train_3pointersuccess_dir, fname)
    
    if os.path.isdir(src):
        shutil.copytree(src, dest)
    else:
        shutil.copy2(src, dest)

#3 
fnames = ['{}'.format(i) for i in range(1,train_data3+1)]
for fname in fnames:
    src = os.path.join(original_dir_freethrowfailure, fname)
    dest = os.path.join(train_freethrowfailure_dir, fname)
    
    if os.path.isdir(src):
        shutil.copytree(src, dest)
    else:
        shutil.copy2(src, dest)
        
#4 
fnames = ['{}'.format(i) for i in range(1,train_data4+1)]
for fname in fnames:
    src = os.path.join(original_dir_freethrowsuccess, fname)
    dest = os.path.join(train_freethrowsuccess_dir, fname)
    
    if os.path.isdir(src):
        shutil.copytree(src, dest)
    else:
        shutil.copy2(src, dest)
        

#5
fnames = ['{}'.format(i) for i in range(1,train_data5+1)]
for fname in fnames:
    src = os.path.join(original_dir_layupfailure, fname)
    dest = os.path.join(train_layupfailure_dir, fname)
    
    if os.path.isdir(src):
        shutil.copytree(src, dest)
    else:
        shutil.copy2(src, dest)

#6 
fnames = ['{}'.format(i) for i in range(1,train_data6+1)]
for fname in fnames:
    src = os.path.join(original_dir_layupsuccess, fname)
    dest = os.path.join(train_layupsuccess_dir, fname)
    
    if os.path.isdir(src):
        shutil.copytree(src, dest)
    else:
        shutil.copy2(src, dest)

#7 
fnames = ['{}'.format(i) for i in range(1,train_data7+1)]
for fname in fnames:
    src = os.path.join(original_dir_other2pointerfailure, fname)
    dest = os.path.join(train_other2pointerfailure_dir, fname)
    
    if os.path.isdir(src):
        shutil.copytree(src, dest)
    else:
        shutil.copy2(src, dest)
        
        
#8 
fnames = ['{}'.format(i) for i in range(1,train_data8+1)]
for fname in fnames:
    src = os.path.join(original_dir_other2pointersuccess, fname)
    dest = os.path.join(train_other2pointersuccess_dir, fname)
    
    if os.path.isdir(src):
        shutil.copytree(src, dest)
    else:
        shutil.copy2(src, dest)
        
#9 
fnames = ['{}'.format(i) for i in range(1,train_data9+1)]
for fname in fnames:
    src = os.path.join(original_dir_slamdunkfailure, fname)
    dest = os.path.join(train_slamdunkfailure_dir, fname)
    
    if os.path.isdir(src):
        shutil.copytree(src, dest)
    else:
        shutil.copy2(src, dest)

#10
fnames = ['{}'.format(i) for i in range(1,train_data10+1)]
for fname in fnames:
    src = os.path.join(original_dir_slamdunksuccess, fname)
    dest = os.path.join(train_slamdunksuccess_dir, fname)
    
    if os.path.isdir(src):
        shutil.copytree(src, dest)
    else:
        shutil.copy2(src, dest)
        
#11
'''fnames = ['{}'.format(i) for i in range(1,train_data11+1)]
for fname in fnames:
    src = os.path.join(original_dir_stealsuccess, fname)
    dest = os.path.join(train_stealsuccess_dir, fname)
    
    if os.path.isdir(src):
        shutil.copytree(src, dest)
    else:
        shutil.copy2(src, dest)'''

        


# In[11]:


# Copy shots to test directories

#1 
fnames = ['{}'.format(i) for i in range(train_data1+1, test_data1+train_data1 + 1)]
for fname in fnames:
    src = os.path.join(original_dir_3pointerfailure, fname)
    dest = os.path.join(test_3pointerfailure_dir, fname)
    
    if os.path.isdir(src):
        shutil.copytree(src, dest)
    else:
        shutil.copy2(src, dest)
        
#2 
fnames = ['{}'.format(i) for i in range(train_data2+1, test_data2+train_data2 + 1)]
for fname in fnames:
    src = os.path.join(original_dir_3pointersuccess, fname)
    dest = os.path.join(test_3pointersuccess_dir, fname)
    
    if os.path.isdir(src):
        shutil.copytree(src, dest)
    else:
        shutil.copy2(src, dest)

#3 
fnames = ['{}'.format(i) for i in range(train_data3+1, test_data3+train_data3 + 1)]
for fname in fnames:
    src = os.path.join(original_dir_freethrowfailure, fname)
    dest = os.path.join(test_freethrowfailure_dir, fname)
    
    if os.path.isdir(src):
        shutil.copytree(src, dest)
    else:
        shutil.copy2(src, dest)
        
#4 
fnames = ['{}'.format(i) for i in range(train_data4+1, test_data4+train_data4 + 1)]
for fname in fnames:
    src = os.path.join(original_dir_freethrowsuccess, fname)
    dest = os.path.join(test_freethrowsuccess_dir, fname)
    
    if os.path.isdir(src):
        shutil.copytree(src, dest)
    else:
        shutil.copy2(src, dest)
        

#5
fnames = ['{}'.format(i) for i in range(train_data5 + 1, test_data5 + train_data5 + 1)]
for fname in fnames:
    src = os.path.join(original_dir_layupfailure, fname)
    dest = os.path.join(test_layupfailure_dir, fname)
    
    if os.path.isdir(src):
        shutil.copytree(src, dest)
    else:
        shutil.copy2(src, dest)

#6 
fnames = ['{}'.format(i) for i in range(train_data6 + 1, test_data6 + train_data6 + 1)]
for fname in fnames:
    src = os.path.join(original_dir_layupsuccess, fname)
    dest = os.path.join(test_layupsuccess_dir, fname)
    
    if os.path.isdir(src):
        shutil.copytree(src, dest)
    else:
        shutil.copy2(src, dest)

#7 
fnames = ['{}'.format(i) for i in range(train_data7 + 1, test_data7 + train_data7 + 1)]
for fname in fnames:
    src = os.path.join(original_dir_other2pointerfailure, fname)
    dest = os.path.join(test_other2pointerfailure_dir, fname)
    
    if os.path.isdir(src):
        shutil.copytree(src, dest)
    else:
        shutil.copy2(src, dest)
        
        
#8 
fnames = ['{}'.format(i) for i in range(train_data8 + 1, test_data8 + train_data8 + 1)]
for fname in fnames:
    src = os.path.join(original_dir_other2pointersuccess, fname)
    dest = os.path.join(test_other2pointersuccess_dir, fname)
    
    if os.path.isdir(src):
        shutil.copytree(src, dest)
    else:
        shutil.copy2(src, dest)
        
#9 
fnames = ['{}'.format(i) for i in range(train_data9 + 1, test_data9 + train_data9 + 1)]
for fname in fnames:
    src = os.path.join(original_dir_slamdunkfailure, fname)
    dest = os.path.join(test_slamdunkfailure_dir, fname)
    
    if os.path.isdir(src):
        shutil.copytree(src, dest)
    else:
        shutil.copy2(src, dest)

#10
fnames = ['{}'.format(i) for i in range(train_data10 + 1, test_data10 + train_data10 + 1)]
for fname in fnames:
    src = os.path.join(original_dir_slamdunksuccess, fname)
    dest = os.path.join(test_slamdunksuccess_dir, fname)
    
    if os.path.isdir(src):
        shutil.copytree(src, dest)
    else:
        shutil.copy2(src, dest)
        
#11
'''fnames = ['{}'.format(i) for i in range(train_data11 + 1, test_data11 + train_data11 + 1)]
for fname in fnames:
    src = os.path.join(original_dir_stealsuccess, fname)
    dest = os.path.join(test_stealsuccess_dir, fname)
    
    if os.path.isdir(src):
        shutil.copytree(src, dest)
    else:
        shutil.copy2(src, dest)'''

        


# In[13]:


# Copy shots to val directories

#1 
fnames = ['{}'.format(i) for i in range(test_data1+train_data1 + 1, test_data1+train_data1 +val_data1 + 1)]
for fname in fnames:
    src = os.path.join(original_dir_3pointerfailure, fname)
    dest = os.path.join(val_3pointerfailure_dir, fname)
    
    if os.path.isdir(src):
        shutil.copytree(src, dest)
    else:
        shutil.copy2(src, dest)
        
#2 
fnames = ['{}'.format(i) for i in range(test_data2+train_data2 + 1, test_data2+train_data2 +val_data2 + 1)]
for fname in fnames:
    src = os.path.join(original_dir_3pointersuccess, fname)
    dest = os.path.join(val_3pointersuccess_dir, fname)
    
    if os.path.isdir(src):
        shutil.copytree(src, dest)
    else:
        shutil.copy2(src, dest)

#3 
fnames = ['{}'.format(i) for i in range(test_data3+train_data3+1, test_data3+train_data3 +val_data3 + 1)]
for fname in fnames:
    src = os.path.join(original_dir_freethrowfailure, fname)
    dest = os.path.join(val_freethrowfailure_dir, fname)
    
    if os.path.isdir(src):
        shutil.copytree(src, dest)
    else:
        shutil.copy2(src, dest)
        
#4 
fnames = ['{}'.format(i) for i in range(test_data4+train_data4+1, test_data4+train_data4 +val_data4 + 1)]
for fname in fnames:
    src = os.path.join(original_dir_freethrowsuccess, fname)
    dest = os.path.join(val_freethrowsuccess_dir, fname)
    
    if os.path.isdir(src):
        shutil.copytree(src, dest)
    else:
        shutil.copy2(src, dest)
        

#5
fnames = ['{}'.format(i) for i in range(test_data5+train_data5+1, test_data5+train_data5 +val_data5 + 1)]
for fname in fnames:
    src = os.path.join(original_dir_layupfailure, fname)
    dest = os.path.join(val_layupfailure_dir, fname)
    
    if os.path.isdir(src):
        shutil.copytree(src, dest)
    else:
        shutil.copy2(src, dest)

#6 
fnames = ['{}'.format(i) for i in range(test_data6+train_data6+1, test_data6+train_data6 +val_data6 + 1)]
for fname in fnames:
    src = os.path.join(original_dir_layupsuccess, fname)
    dest = os.path.join(val_layupsuccess_dir, fname)
    
    if os.path.isdir(src):
        shutil.copytree(src, dest)
    else:
        shutil.copy2(src, dest)

#7 
fnames = ['{}'.format(i) for i in range(test_data7+train_data7+1, test_data7+train_data7 +val_data7 + 1)]
for fname in fnames:
    src = os.path.join(original_dir_other2pointerfailure, fname)
    dest = os.path.join(val_other2pointerfailure_dir, fname)
    
    if os.path.isdir(src):
        shutil.copytree(src, dest)
    else:
        shutil.copy2(src, dest)
        
        
#8 
fnames = ['{}'.format(i) for i in range(test_data8+train_data8+1, test_data8+train_data8 +val_data8 + 1)]
for fname in fnames:
    src = os.path.join(original_dir_other2pointersuccess, fname)
    dest = os.path.join(val_other2pointersuccess_dir, fname)
    
    if os.path.isdir(src):
        shutil.copytree(src, dest)
    else:
        shutil.copy2(src, dest)
        
#9 
fnames = ['{}'.format(i) for i in range(test+data9+train_data9+1, test_data9+train_data9 +val_data9 + 1)]
for fname in fnames:
    src = os.path.join(original_dir_slamdunkfailure, fname)
    dest = os.path.join(val_slamdunkfailure_dir, fname)
    
    if os.path.isdir(src):
        shutil.copytree(src, dest)
    else:
        shutil.copy2(src, dest)

#10
fnames = ['{}'.format(i) for i in range(test_data10+train_data10+1, test_data10+train_data10 +val_data10 + 1)]
for fname in fnames:
    src = os.path.join(original_dir_slamdunksuccess, fname)
    dest = os.path.join(val_slamdunksuccess_dir, fname)
    
    if os.path.isdir(src):
        shutil.copytree(src, dest)
    else:
        shutil.copy2(src, dest)
        
#11
'''fnames = ['{}'.format(i) for i in range(train_data11 + 1, val_data11 + train_data11 + 1)]
for fname in fnames:
    src = os.path.join(original_dir_stealsuccess, fname)
    dest = os.path.join(val_stealsuccess_dir, fname)
    
    if os.path.isdir(src):
        shutil.copytree(src, dest)
    else:
        shutil.copy2(src, dest)'''

        


# In[15]:


#9 
fnames = ['{}'.format(i) for i in range(test_data9+train_data9+1, test_data9+train_data9 +val_data9 + 1)]
for fname in fnames:
    src = os.path.join(original_dir_slamdunkfailure, fname)
    dest = os.path.join(val_slamdunkfailure_dir, fname)
    
    if os.path.isdir(src):
        shutil.copytree(src, dest)
    else:
        shutil.copy2(src, dest)


# In[16]:


#10
fnames = ['{}'.format(i) for i in range(test_data10+train_data10+1, test_data10+train_data10 +val_data10 + 1)]
for fname in fnames:
    src = os.path.join(original_dir_slamdunksuccess, fname)
    dest = os.path.join(val_slamdunksuccess_dir, fname)
    
    if os.path.isdir(src):
        shutil.copytree(src, dest)
    else:
        shutil.copy2(src, dest)


# In[ ]:




