import cv2
import os


def createfolder(direc):
    try:
        if not os.path.exists(direc):
            os.makedirs(direc)
    except OSError:
        print("Error creating directory"+direc)
            
file = open('data.csv','r')

time_stamp = []
video_list = []
for line in file:
    line = line.split(',')
    line = [line[9],float(line[5]),float(line[6]),line[0]]
    if (line not in time_stamp) and (line[2]-line[1] <= 10000):
        time_stamp.append(line)

for line in time_stamp:
    #line = line.split(',')
    line = line[3]
    if line not in video_list:
        video_list.append(line)
#print(time_stamp)
print(video_list)

events = []
for i in time_stamp:
	if i[0] not in events:
		events.append(i[0])
print(events)
    

filelist = os.listdir('I:\\Video_Files')
print(filelist)

for eve in events:
	for event in filelist:
		for id in video_list:
			filelist2 = os.listdir( 'I:\\Video_Files\\{}\\{}'.format(event,id) )
			#print(filelist2)
			for sv in filelist2:
				if sv == "vid.mp4":
					continue   
				vidcap = cv2.VideoCapture('I:\\Video_Files\\{}\\{}\\{}'.format(event, id,sv))
				success,image = vidcap.read()
				count = 0
				frame_ctr = 0
				success = True
				if event == eve:
					while success:
						if count%1 == 0:
							path_p1 = 'C:/frames/{}/{}'.format(eve,sv)
							createfolder(path_p1)
							cv2.imwrite(path_p1+'/frame%d.jpg'%frame_ctr,image)
							frame_ctr+=1
							success, image = vidcap.read()
							count+=1

#Renaming folder names to digits				
frame_fs = os.listdir('C:/frames/')
for i in frame_fs:
    filepath = 'C:/frames/{}'.format(i) 
    os.chdir(filepath)
    for num, filename in enumerate(os.listdir(os.getcwd()), start= 1):
        fname, ext = filename, ''
        
        os.rename(filename, '%s' %num + '.' + ext) 